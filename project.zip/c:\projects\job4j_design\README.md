<h1>job4j_design</h1>

<h2>О проекте</h2>
Учебный проект уровня "Junior" обучающего курса https://job4j.ru

<h3>Коллекции Pro</h3>
- Параметризованные типы, Wildcard<br>
- Итераторы<br>
- Внутреннее устройство коллекций<br>
- Hashcode, equals
<h3>ООД</h3>
- Принципы SOLID<br>
- Разработка через тестирование (TDD)
<h3>Память</h3>
- Cборщик мусора<br>
- Типы сборщиков<br>
- Профилирование приложений<br>
- Soft weak ссылки и коллекции
<h3>Ввод-вывод, Socket</h3>
- InputStreams, OutputStreams<br>
- Readers, Writers<br>
- Scanner<br>
- Файловые менеджеры<br>
- Сокеты<br>
- Внешняя сортировка файлов
<h3>SQL, JDBC</h3>
- Общие сведения о базах данных на основе PostgreSQL<br>
- Базовый синтаксис SQL<br>
- Запросы Select, Join, Outer Left, Right<br>
- JDBC<br>
- Индексирование, внешние ключи, естественные ключи
